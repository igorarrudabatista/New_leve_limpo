Product Name
---------------
CryptoDash - Free Cryptocurrency Dashboard Template


Product Description
-------------------
CryptoDash - Cryptocurrency Dashboard Template is fully responsive, super flexible, powerful, clean and complete solution for your crypto currencies ico start up agency. Every crypto business and their ICO have different crowdsales process for token sale. We have done deep research on required pages, process, functionalities & elements for every ICO business and provided Dashboard, Purchase Token, Wallet, Transactions, FAQ, Login history, User profile, Login, Register and many more pages UI.

CryptoDash Cryptocurrency Dashboard Template is powered with HTML 5, SASS, GRUNT, Gulp & Twitter Bootstrap 4 which looks great on Desktops, Tablets and Mobile Devices. CryptoDash bootstrap admin template help ico start up agency to create their ICO Admin Dashboard easily.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeSelection. You can access documentation online as well.
Documentation URL: https://themeselection.com/demo/cryptodash-free-cryptocurrency-dashboard-template/documentation/

Change Log
----------
Read CHANGELOG.md file