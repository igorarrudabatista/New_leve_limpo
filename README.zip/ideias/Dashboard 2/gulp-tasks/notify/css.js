var notify = require("gulp-notify");

module.exports = function(gulp, callback) {
	return notify("CSS Build Complete!!");
};