# Bootstrap Wizard powered by Vue2

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrgl86/pen/NRqzww](https://codepen.io/chrgl86/pen/NRqzww).

