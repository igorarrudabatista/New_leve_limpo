INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Locação Toalha Hair', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Hig. Toalha Hair', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Manicure', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Ombro Tintura', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Capa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Banho', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Tapete', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Lençol', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Roupão', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Locação Toalha PE', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Cobertor', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Trav. Almofada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Hig. Toalha', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Caminha', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Preta', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Dourada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Rosa', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Azul Escuro', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Verde', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Cinza', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Laranja', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Azul Claro', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Roxo', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Bordô', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Lilás', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Vermelha', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Azul', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Verde Claro', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `produtos` (`id`, `Nome_Produto`, `Categoria_Produto`, `Status_Produto`, `Preco_Produto`, `Estoque_Produto`, `Quantidade_Produto`, `image`, `created_at`, `updated_at`) 
VALUES (NULL, 'Toalha Marrom', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);